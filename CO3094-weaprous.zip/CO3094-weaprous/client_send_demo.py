import socket
import threading
import datetime

def handle_client(conn, addr, username):
    try:
        data = conn.recv(4096).decode()
        if not data:
            return

        print(f"\n[{username}] Message received from {addr}")
        print("-------- RAW MESSAGE --------")
        print(data)
        print("-----------------------------")

        # Trích phần body nếu có
        if "\r\n\r\n" in data:
            body = data.split("\r\n\r\n", 1)[1]
            print(f"[{username}] Content: {body.strip()}")

        # Phản hồi
        conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nOK")
    except Exception as e:
        print(f"[{username}] Error: {e}")
    finally:
        conn.close()


def start_peer_server(ip, port, username):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((ip, port))
        s.listen(5)
        print(f"[PeerServer:{username}] Listening on {ip}:{port}")

        while True:
            conn, addr = s.accept()
            threading.Thread(
                target=handle_client,
                args=(conn, addr, username),
                daemon=True
            ).start()
    except Exception as e:
        print(f"[PeerServer:{username}] Failed to start: {e}")


def prepare_http_request(message):
    headers = {
        "Host": "127.0.0.1",
        "Content-Type": "text/plain",
        "Content-Length": str(len(message)),
        "User-Agent": "PeerDemo/1.0",
        "Date": datetime.datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
    }

    fmt_header = "POST /send-peer HTTP/1.1\r\n"
    for key, value in headers.items():
        fmt_header += f"{key}: {value}\r\n"
    fmt_header += "\r\n"

    return (fmt_header + message).encode("utf-8")


def send_to_peer(target_ip, target_port, message):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((target_ip, target_port))
        s.sendall(prepare_http_request(message))
        resp = s.recv(1024).decode()
        print(f"[PeerClient] Response from {target_ip}:{target_port} → {resp}")
    except Exception as e:
        print(f"[PeerClient] Send failed: {e}")
    finally:
        s.close()


if __name__ == "__main__":
    username = input("Enter your username: ")
    port = int(input("Enter your listening port: "))

    threading.Thread(target=start_peer_server, args=("0.0.0.0", port, username), daemon=True).start()

    print(f"\n[{username}] Peer is running.")
    print("Type 'send' to send a message, or 'exit' to quit.\n")

    while True:
        cmd = input("> ").strip().lower()

        if cmd == "exit":
            print("Exiting...")
            break

        elif cmd == "send":
            target_ip = input("Target IP: ").strip() or "127.0.0.1"
            target_port = int(input("Target Port: ").strip())
            message = input("Message: ").strip()
            send_to_peer(target_ip, target_port, message)

        else:
            print("Unknown command. Type 'send' or 'exit'.")
