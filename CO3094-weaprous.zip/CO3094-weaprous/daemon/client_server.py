import socket
import threading

def handle_client(conn, addr, username):
    try:
        data = conn.recv(2048).decode('utf-8')
        if not data:
            return
        
        print(f"[{username}] Received message from {addr}: {data}")
        conn.sendall(b"OK")

        # TODO (sau này):
        # - Lưu tin nhắn vào log
        # - Forward lên frontend qua WebSocket / long-polling

    except Exception as e:
        print(f"[{username}]Error handling client {addr}: {e}")
    finally:
        conn.close()


def start_peer_server(ip: str, port: int, username: str):
    """
    Khởi chạy 1 mini TCP server cho mỗi peer sau khi login thành công.

    Args:
        ip (str): địa chỉ IP để bind (thường là '0.0.0.0')
        port (int): cổng lắng nghe cho peer này
        username (str): tên người dùng hiện tại
    """
    try:
        peer_server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        peer_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        peer_server.bind((ip, port))
        peer_server.listen(5)

        print(f"[PeerServer] Started for user '{username}' on {ip}:{port}")

        while True:
            conn, addr = peer_server.accept()
            print(f"[PeerServer:{username}] Connection from {addr}")

            client_thread = threading.Thread(
                target=handle_client,
                args=(conn, addr, username),
                daemon=True
            )
            client_thread.start()

    except Exception as e:
        print(f"[PeerServer:{username}] Failed to start: {e}")